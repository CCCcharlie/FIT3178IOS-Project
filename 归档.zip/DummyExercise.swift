//
//  DummyExercise.swift
//  Assessment 1
//
//  Created by Cly Cly on 17/5/2024.
//

import UIKit

//class DummyExercise {
//    var bodyPart: String
//    var equipment: String
//    var gifUrl: String
//    var id: String
//    var name: String
//    var target: String
//    var secondaryMuscles: [String]
//    var instructions: [String]
//
//    init(bodyPart: String, equipment: String, gifUrl: String, id: String, name: String, target: String, secondaryMuscles: [String], instructions: [String]) {
//        self.bodyPart = bodyPart
//        self.equipment = equipment
//        self.gifUrl = gifUrl
//        self.id = id
//        self.name = name
//        self.target = target
//        self.secondaryMuscles = secondaryMuscles
//        self.instructions = instructions
//    }
//}

