//
//  File.swift
//  Assessment 1
//
//  Created by Cly Cly on 10/5/2024.
//

import UIKit

class SubmenuCollectionViewController: UICollectionViewController {
    var exercises: [DummyExercise] = []

    // Custom initializer to pass exercises
//    init(exercises: [DummyExercise]) {
//        self.exercises = exercises
//        let layout = UICollectionViewFlowLayout()
//        super.init(collectionViewLayout: layout)
//    }
//
//    required init?(coder: NSCoder) {
//        super.init(coder: coder)
//    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("Exercises in viewDidLoad: \(exercises)") // 确认初始化后的 exercises 不为空
    }

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("Exercises in sub \(exercises)") // 确认在 collectionView 数据源方法中 exercises 不为空
        return exercises.count
    }

//    // Method to configure exercises after initialization
//    func configure(exercises: [DummyExercise]) {
//        self.exercises = exercises
//    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SubmenuCell", for: indexPath) as! SubmenuCell

        let exercise = exercises[indexPath.item]
        cell.titleLabel.text = exercise.name
        
        if !exercise.gifUrl.isEmpty {
            if let gifUrl = URL(string: exercise.gifUrl) {
                URLSession.shared.dataTask(with: gifUrl) { (data, response, error) in
                    guard let data = data, let image = UIImage(data: data) else {
                        DispatchQueue.main.async {
                            cell.imageView.image = UIImage(named: "placeholder_image") // Placeholder image
                        }
                        return
                    }
                    DispatchQueue.main.async {
                        cell.imageView.image = image
                    }
                }.resume()
            }
        } else {
            cell.imageView.image = UIImage(named: "placeholder_image") // Placeholder image
        }
        
        return cell
    }
    func createWorkshop2Layout3() -> UICollectionViewLayout {
        let itemSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(0.5), heightDimension: .fractionalHeight(1.0))
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 1.0, bottom: 0, trailing: 1.0)
            
        let groupSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(0.8), heightDimension: .fractionalWidth(0.6))
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])
      
        let section = NSCollectionLayoutSection(group: group)
        section.orthogonalScrollingBehavior = .groupPaging

        // Section header
        let headerSize = NSCollectionLayoutSize(widthDimension: .fractionalWidth(1.0), heightDimension: .absolute(40))
        let headerLayout = NSCollectionLayoutBoundarySupplementaryItem(layoutSize: headerSize, elementKind: UICollectionView.elementKindSectionHeader, alignment: .top)
        section.boundarySupplementaryItems = [headerLayout]

        let layout = UICollectionViewCompositionalLayout(section: section)
        return layout
    }
}
