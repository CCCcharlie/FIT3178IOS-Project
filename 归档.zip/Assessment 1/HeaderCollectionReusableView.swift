//
//  header.swift
//  Assessment 1
//
//  Created by Cly Cly on 3/5/2024.
//

import UIKit

class HeaderCollectionReusableView: UICollectionReusableView {
    @IBOutlet weak var labelTextView: UILabel!
    
}
