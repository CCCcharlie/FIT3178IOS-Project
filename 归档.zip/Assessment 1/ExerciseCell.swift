//
//  ExerciseCell.swift
//  Assessment 1
//
//  Created by Cly Cly on 3/5/2024.
//

import UIKit

class ExerciseCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!

    
}

