//
//  SubmenuCell.swift
//  Assessment 1
//
//  Created by Cly Cly on 10/5/2024.
//

import UIKit

class SubmenuCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!

    
}
